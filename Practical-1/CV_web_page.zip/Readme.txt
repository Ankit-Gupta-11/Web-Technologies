
I got help from below given youtube link video

https://www.youtube.com/watch?v=zAVhHHS_IH4




You can verify my kaggle profile and projects done by me on it

https://www.kaggle.com/nkitgupta




You can verify my Deep learning certificate at

coursera.org/verif y/ZTURJMZUG7HX



You Can verify my machine learning certificate at

coursera.org/verif y/3GUH42ESDUQ3